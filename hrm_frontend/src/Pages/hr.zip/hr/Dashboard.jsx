import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Users, CalendarCheck, FileText, DollarSign,
  Building2, BarChart3, LogOut, Bell, Menu, X, UserPlus, TrendingUp,
  CheckCircle, XCircle, Clock, Award, UserCheck, Search,
  Loader, RefreshCw, Save, AlertCircle,
} from "lucide-react";
import logo from "../../assets/logo.jpg";

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const BASE_URL = "http://localhost:5004/api";

const api = {
  get: async (path) => {
    const token = localStorage.getItem("token");
    const res = await fetch(`${BASE_URL}${path}`, {
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },
  post: async (path, body) => {
    const token = localStorage.getItem("token");
    const res = await fetch(`${BASE_URL}${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return res.json();
  },
  put: async (path, body) => {
    const token = localStorage.getItem("token");
    const res = await fetch(`${BASE_URL}${path}`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },
};

// ─── TOAST ────────────────────────────────────────────────────────────────────
const Toast = ({ toasts, removeToast }) => (
  <div className="fixed top-4 right-4 z-50 space-y-2">
    {toasts.map((t) => (
      <div key={t.id} className={`flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium
        ${t.type === "success" ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
          : t.type === "error" ? "bg-red-50 text-red-700 border border-red-200"
          : "bg-blue-50 text-blue-700 border border-blue-200"}`}>
        {t.type === "success" ? <CheckCircle size={15} /> : t.type === "error" ? <XCircle size={15} /> : <AlertCircle size={15} />}
        {t.message}
        <button onClick={() => removeToast(t.id)} className="ml-1 opacity-60 hover:opacity-100"><X size={13} /></button>
      </div>
    ))}
  </div>
);

const useToast = () => {
  const [toasts, setToasts] = useState([]);
  const addToast = (message, type = "info") => {
    const id = Date.now();
    setToasts((p) => [...p, { id, message, type }]);
    setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), 4000);
  };
  const removeToast = (id) => setToasts((p) => p.filter((t) => t.id !== id));
  return { toasts, addToast, removeToast };
};

// ─── ADD EMPLOYEE MODAL (CENTERED) ────────────────────────────────────────────
const AddEmployeePanel = ({ open, onClose, onSuccess, toast }) => {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    employeeId: "", fullName: "", email: "", password: "",
    nic: "", dob: "", address: "", phone: "", gender: "",
    department: "", role: "EMPLOYEE", designation: "",
    joiningDate: new Date().toISOString().split("T")[0],
    employmentType: "",
  });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const resetForm = () => setForm({
    employeeId: "", fullName: "", email: "", password: "",
    nic: "", dob: "", address: "", phone: "", gender: "",
    department: "", role: "EMPLOYEE", designation: "",
    joiningDate: new Date().toISOString().split("T")[0],
    employmentType: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.employeeId || !form.fullName || !form.email || !form.password) {
      toast.addToast("Please fill all required fields", "error");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        dob: form.dob || null,
        joiningDate: form.joiningDate || null,
      };
      await api.post("/hr/employees", payload);
      toast.addToast("Employee created successfully!", "success");
      resetForm();
      onSuccess();
      onClose();
    } catch (err) {
      toast.addToast(err.message || "Failed to create employee", "error");
    } finally {
      setSaving(false);
    }
  };

  const ic = "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition";
  const lc = "block text-xs font-semibold text-gray-600 mb-1";

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col z-10">

        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-5 flex items-center justify-between flex-shrink-0 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg"><UserPlus className="text-white" size={20} /></div>
            <div>
              <h2 className="text-white font-bold text-lg">Add New Employee</h2>
              <p className="text-blue-100 text-xs">Fill in the details below</p>
            </div>
          </div>
          <button onClick={onClose} className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition">
            <X className="text-white" size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-2 gap-4">
            {/* Full Name */}
            <div>
              <label className={lc}>Full Name <span className="text-red-500">*</span></label>
              <input name="fullName" value={form.fullName} onChange={handleChange} placeholder="John Doe" className={ic} required />
            </div>
            {/* Employee ID */}
            <div>
              <label className={lc}>Employee ID <span className="text-red-500">*</span></label>
              <input name="employeeId" value={form.employeeId} onChange={handleChange} placeholder="EMP001" className={ic} required />
            </div>
            {/* Email */}
            <div className="col-span-2">
              <label className={lc}>Email Address <span className="text-red-500">*</span></label>
              <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="john@company.com" className={ic} required />
            </div>
            {/* Password */}
            <div className="col-span-2">
              <label className={lc}>Password <span className="text-red-500">*</span></label>
              <input name="password" type="password" value={form.password} onChange={handleChange} placeholder="••••••••" className={ic} required />
            </div>
            {/* Phone */}
            <div>
              <label className={lc}>Phone</label>
              <input name="phone" value={form.phone} onChange={handleChange} placeholder="+94 77 000 0000" className={ic} />
            </div>
            {/* NIC */}
            <div>
              <label className={lc}>NIC</label>
              <input name="nic" value={form.nic} onChange={handleChange} placeholder="123456789V" className={ic} />
            </div>
            {/* DOB */}
            <div>
              <label className={lc}>Date of Birth</label>
              <input name="dob" type="date" value={form.dob} onChange={handleChange} className={ic} />
            </div>
            {/* Gender */}
            <div>
              <label className={lc}>Gender</label>
              <select name="gender" value={form.gender} onChange={handleChange} className={ic}>
                <option value="">Select gender</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            {/* Department */}
            <div className="col-span-2">
              <label className={lc}>Department</label>
              <input name="department" value={form.department} onChange={handleChange} placeholder="e.g. Engineering, Finance" className={ic} />
            </div>
            {/* Role */}
            <div>
              <label className={lc}>Role</label>
              <select name="role" value={form.role} onChange={handleChange} className={ic}>
                <option value="EMPLOYEE">Employee</option>
                <option value="HR_MANAGER">HR Manager</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>
            {/* Designation */}
            <div>
              <label className={lc}>Designation</label>
              <input name="designation" value={form.designation} onChange={handleChange} placeholder="Software Engineer" className={ic} />
            </div>
            {/* Employment Type */}
            <div>
              <label className={lc}>Employment Type <span className="text-red-500">*</span></label>
              <select name="employmentType" value={form.employmentType} onChange={handleChange} className={ic} required>
                <option value="">Select type</option>
                <option value="FULL_TIME">Full Time</option>
                <option value="PART_TIME">Part Time</option>
                <option value="CONTRACT">Contract</option>
                <option value="INTERNSHIP">Internship</option>
                <option value="FREELANCE">Freelance</option>
              </select>
            </div>
            {/* Joining Date */}
            <div>
              <label className={lc}>Joining Date</label>
              <input name="joiningDate" type="date" value={form.joiningDate} onChange={handleChange} className={ic} />
            </div>
            {/* Address */}
            <div className="col-span-2">
              <label className={lc}>Address</label>
              <input name="address" value={form.address} onChange={handleChange} placeholder="123 Main St, City" className={ic} />
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="p-5 border-t bg-gray-50 flex gap-3 flex-shrink-0 rounded-b-2xl">
          <button onClick={() => { resetForm(); onClose(); }} type="button"
            className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-100 transition">
            Cancel
          </button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2">
            {saving ? <Loader className="animate-spin" size={16} /> : <Save size={16} />}
            {saving ? "Creating..." : "Create Employee"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── EMPLOYMENT TYPE BADGE ─────────────────────────────────────────────────────
const employmentTypeBadge = (type) => {
  const normalized = type?.toString().toUpperCase().replace(/[\s-]/g, "_");
  const styles = {
    FULL_TIME:   "bg-blue-100 text-blue-700 border border-blue-200",
    PART_TIME:   "bg-purple-100 text-purple-700 border border-purple-200",
    CONTRACT:    "bg-orange-100 text-orange-700 border border-orange-200",
    INTERNSHIP:  "bg-pink-100 text-pink-700 border border-pink-200",
    FREELANCE:   "bg-teal-100 text-teal-700 border border-teal-200",
  };
  const labels = {
    FULL_TIME: "Full Time",
    PART_TIME: "Part Time",
    CONTRACT: "Contract",
    INTERNSHIP: "Internship",
    FREELANCE: "Freelance",
  };
  if (!normalized || !labels[normalized]) {
    return <span className="text-gray-400 text-xs">—</span>;
  }
  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${styles[normalized]}`}>
      {labels[normalized]}
    </span>
  );
};

// ─── EMPLOYEE TABLE ────────────────────────────────────────────────────────────
const EmployeeTable = ({ toast, onAddClick, refreshKey }) => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get("/hr/employees");
      const data = res.data || [];
      // Log raw fields so we can see what API actually returns
      if (data.length > 0) console.log("[Employee fields]", Object.keys(data[0]), data[0]);
      setEmployees(data);
    } catch {
      toast.addToast("Failed to load employees", "error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchEmployees(); }, [fetchEmployees, refreshKey]);

  const handleDeactivate = async (id, name) => {
    if (!window.confirm(`Deactivate ${name}?`)) return;
    try {
      await api.put(`/hr/employees/${id}/deactivate`);
      toast.addToast("Employee deactivated", "success");
      fetchEmployees();
    } catch { toast.addToast("Failed to deactivate", "error"); }
  };

  const filtered = employees.filter((e) =>
    e.fullName?.toLowerCase().includes(search.toLowerCase()) ||
    e.email?.toLowerCase().includes(search.toLowerCase()) ||
    e.employeeId?.toLowerCase().includes(search.toLowerCase()) ||
    e.department?.toLowerCase().includes(search.toLowerCase()) ||
    e.departmentName?.toLowerCase().includes(search.toLowerCase())
  );

  const statusBadge = (s) => {
    const c = {
      ACTIVE: "bg-emerald-100 text-emerald-700",
      INACTIVE: "bg-gray-100 text-gray-600",
      TERMINATED: "bg-red-100 text-red-700",
    };
    return <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${c[s] || "bg-gray-100 text-gray-600"}`}>{s}</span>;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-5 border-b flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
          <div className="bg-blue-100 p-1.5 rounded-lg"><Users className="text-blue-600" size={18} /></div>
          All Employees
          <span className="text-sm font-normal text-gray-400">({filtered.length})</span>
        </h3>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search..." className="pl-8 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-48" />
          </div>
          <button onClick={fetchEmployees} className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition">
            <RefreshCw size={15} />
          </button>
          <button onClick={onAddClick}
            className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
            <UserPlus size={15} /> Add Employee
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader className="animate-spin text-blue-500" size={28} />
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                {["Employee", "ID", "Department", "Designation", "Role", "Employment Type", "Joining Date", "Status", "Actions"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-16 text-gray-400">
                  <Users size={36} className="mx-auto mb-2 opacity-20" />
                  <p>No employees found</p>
                </td></tr>
              ) : filtered.map((emp) => (
                <tr key={emp.id} className="hover:bg-gray-50 transition">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                        {emp.fullName?.charAt(0)}
                      </div>
                      <div>
                        <p className="font-semibold text-sm text-gray-800">{emp.fullName}</p>
                        <p className="text-xs text-gray-400">{emp.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-sm font-mono text-gray-600">{emp.employeeId}</td>
                  {/* Department: check every possible API field name */}
                  <td className="px-5 py-3.5 text-sm text-gray-600">
                    {(() => {
                      const dept = emp.departmentName || emp.department || emp.dept
                        || emp.departmentTitle || emp.department_name || emp.deptName;
                      return dept
                        ? <span className="bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full text-xs font-semibold border border-indigo-100">{dept}</span>
                        : <span className="text-gray-400 text-xs">—</span>;
                    })()}
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-600">{emp.designation || "—"}</td>
                  <td className="px-5 py-3.5">
                    <span className="bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded-full text-xs font-semibold">{emp.role}</span>
                  </td>
                  {/* Employment Type column: check all possible API field names */}
                  <td className="px-5 py-3.5">
                    {employmentTypeBadge(
                      emp.employmentType || emp.employment_type || emp.empType || emp.type
                    )}
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-500">{emp.joiningDate || "—"}</td>
                  <td className="px-5 py-3.5">{statusBadge(emp.status)}</td>
                  <td className="px-5 py-3.5">
                    <button onClick={() => handleDeactivate(emp.id, emp.fullName)}
                      className="p-1.5 hover:bg-orange-50 text-orange-500 rounded-lg transition" title="Deactivate">
                      <XCircle size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ─── MAIN DASHBOARD ───────────────────────────────────────────────────────────
const HRDashboard = () => {
  const [user, setUser] = useState(null);
  const [activeMenu, setActiveMenu] = useState("Overview");
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [stats, setStats] = useState({ totalEmployees: 0, activeEmployees: 0, pendingLeaves: 0, todayPresent: 0 });
  const [pendingLeaves, setPendingLeaves] = useState([]);
  const [empRefresh, setEmpRefresh] = useState(0);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      if (userData.role !== "HR_MANAGER" && userData.role !== "ADMIN") {
        navigate("/unauthorized");
        return;
      }
      setUser(userData);
    } else {
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    if (user) fetchDashboardData();
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, leavesRes] = await Promise.all([
        api.get("/hr/dashboard/stats").catch(() => ({ data: {} })),
        api.get("/hr/leaves/pending").catch(() => ({ data: [] })),
      ]);
      if (statsRes?.data) {
        setStats({
          totalEmployees: statsRes.data.totalEmployees || 0,
          activeEmployees: statsRes.data.activeEmployees || 0,
          pendingLeaves: statsRes.data.pendingLeaveApplications || 0,
          todayPresent: statsRes.data.todayPresent || 0,
        });
      }
      setPendingLeaves(leavesRes?.data || []);
    } catch {}
  };

  const handleApproveLeave = async (id) => {
    try {
      await api.put(`/hr/leaves/${id}/approve`);
      toast.addToast("Leave approved", "success");
      fetchDashboardData();
    } catch { toast.addToast("Failed to approve", "error"); }
  };

  const handleRejectLeave = async (id) => {
    const reason = window.prompt("Reason for rejection:");
    if (reason === null) return;
    try {
      await api.put(`/hr/leaves/${id}/reject?reason=${encodeURIComponent(reason || "Rejected")}`);
      toast.addToast("Leave rejected", "success");
      fetchDashboardData();
    } catch { toast.addToast("Failed to reject", "error"); }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  const menuItems = [
    { name: "Overview", icon: LayoutDashboard },
    { name: "Employees", icon: Users },
    { name: "Departments", icon: Building2 },
    { name: "Attendance", icon: CalendarCheck },
    { name: "Leave Management", icon: FileText },
    { name: "Payroll", icon: DollarSign },
    { name: "Reports", icon: BarChart3 },
  ];

  if (!user) return (
    <div className="flex items-center justify-center h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500" />
    </div>
  );

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
      <Toast toasts={toast.toasts} removeToast={toast.removeToast} />

      {/* Add Employee Modal (centered) */}
      <AddEmployeePanel
        open={showAddEmployee}
        onClose={() => setShowAddEmployee(false)}
        onSuccess={() => {
          setEmpRefresh(r => r + 1);
          fetchDashboardData();
          setActiveMenu("Employees");
        }}
        toast={toast}
      />

      {/* ── SIDEBAR ── */}
      <aside className={`${isSidebarOpen ? "w-64" : "w-20"} bg-white shadow-lg transition-all duration-300 flex flex-col flex-shrink-0`}>
        <div className="p-4 border-b flex items-center justify-between">
          {isSidebarOpen && (
            <div className="flex items-center gap-2">
              <img src={logo} alt="Logo" className="h-10 w-10 rounded" />
              <div>
                <h1 className="font-bold text-lg">HRM System</h1>
                <p className="text-xs text-gray-500">HR Manager</p>
              </div>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-gray-100 rounded">
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <button key={item.name} onClick={() => setActiveMenu(item.name)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                activeMenu === item.name ? "bg-blue-500 text-white" : "hover:bg-gray-100 text-gray-700"}`}>
              <item.icon size={20} />
              {isSidebarOpen && <span>{item.name}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t">
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-red-50 text-red-600 transition-colors">
            <LogOut size={20} />
            {isSidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* ── MAIN ── */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white shadow-sm p-4 flex items-center justify-between sticky top-0 z-20">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{activeMenu}</h2>
            <p className="text-sm text-gray-500">HR Management Dashboard</p>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 hover:bg-gray-100 rounded-full">
              <Bell size={20} />
              {stats.pendingLeaves > 0 && (
                <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                  {stats.pendingLeaves}
                </span>
              )}
            </button>
            <div className="flex items-center gap-2">
              <div className="text-right">
                <p className="text-sm font-medium">{user.fullName}</p>
                <p className="text-xs text-gray-500">{user.role}</p>
              </div>
              <div className="h-10 w-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                {user.fullName?.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        <div className="p-6">

          {/* ── OVERVIEW ── */}
          {activeMenu === "Overview" && (
            <div>
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                {[
                  { label: "Total Employees", val: stats.totalEmployees, sub: "Across all departments", icon: Users, from: "from-blue-500", to: "to-blue-600", tc: "text-blue-100" },
                  { label: "Active Employees", val: stats.activeEmployees, sub: "Currently working", icon: CheckCircle, from: "from-green-500", to: "to-emerald-600", tc: "text-green-100" },
                  { label: "Pending Leaves", val: stats.pendingLeaves, sub: "Awaiting approval", icon: Clock, from: "from-yellow-500", to: "to-orange-500", tc: "text-yellow-100" },
                  { label: "Today Present", val: stats.todayPresent, sub: "Checked in today", icon: UserCheck, from: "from-purple-500", to: "to-pink-600", tc: "text-purple-100" },
                ].map(({ label, val, sub, icon: Icon, from, to, tc }) => (
                  <div key={label} className={`bg-gradient-to-br ${from} ${to} p-6 rounded-xl shadow-xl text-white transform hover:scale-105 hover:shadow-2xl transition-all duration-300 cursor-pointer relative overflow-hidden`}>
                    <div className="absolute top-0 right-0 w-24 h-24 bg-white opacity-10 rounded-full -mr-12 -mt-12" />
                    <div className="flex items-center justify-between mb-3 relative z-10">
                      <div className="bg-white bg-opacity-20 p-3 rounded-lg"><Icon size={28} /></div>
                    </div>
                    <p className={`${tc} text-sm font-medium mb-1 relative z-10`}>{label}</p>
                    <h3 className="text-4xl font-bold relative z-10">{val}</h3>
                    <p className={`text-sm ${tc} mt-2 relative z-10`}>{sub}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                {/* Pending Leaves */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                  <h3 className="text-xl font-bold mb-6 flex items-center justify-between text-gray-800">
                    <span className="flex items-center">
                      <div className="bg-yellow-100 p-2 rounded-lg mr-3"><FileText className="text-yellow-600" size={24} /></div>
                      Pending Leave Requests
                    </span>
                    <span className="text-sm text-gray-500 font-normal bg-yellow-100 px-3 py-1 rounded-full">
                      {pendingLeaves.length} pending
                    </span>
                  </h3>
                  <div className="space-y-3">
                    {pendingLeaves.length === 0 ? (
                      <div className="text-center py-8 text-gray-400">
                        <CheckCircle size={32} className="mx-auto mb-2 opacity-30" />
                        <p className="text-sm">No pending leave requests</p>
                      </div>
                    ) : pendingLeaves.slice(0, 5).map((leave) => (
                      <div key={leave.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 transition">
                        <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-600 flex-shrink-0">
                          {leave.employeeName?.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold">{leave.employeeName}</p>
                          <p className="text-sm text-gray-500">{leave.leaveTypeName} • {leave.numberOfDays} day(s)</p>
                          <p className="text-xs text-gray-400">{leave.startDate} → {leave.endDate}</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleApproveLeave(leave.id)} className="bg-green-500 text-white px-3 py-1.5 rounded-lg hover:bg-green-600 transition flex items-center gap-1 text-sm">
                            <CheckCircle size={14} /> Approve
                          </button>
                          <button onClick={() => handleRejectLeave(leave.id)} className="bg-red-500 text-white px-3 py-1.5 rounded-lg hover:bg-red-600 transition flex items-center gap-1 text-sm">
                            <XCircle size={14} /> Reject
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                  <h3 className="text-xl font-bold mb-6 flex items-center text-gray-800">
                    <div className="bg-blue-100 p-2 rounded-lg mr-3"><LayoutDashboard className="text-blue-600" size={24} /></div>
                    Quick Actions
                  </h3>
                  <div className="space-y-3">
                    <button onClick={() => setShowAddEmployee(true)}
                      className="w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition flex items-center justify-center gap-2 font-medium">
                      <UserPlus size={20} /> Add New Employee
                    </button>
                    <button onClick={() => navigate("/hr/payslip")}
                      className="w-full bg-green-500 text-white py-3 px-4 rounded-lg hover:bg-green-600 transition flex items-center justify-center gap-2 font-medium">
                      <DollarSign size={20} /> Generate Payslips
                    </button>
                    <button onClick={() => setActiveMenu("Reports")}
                      className="w-full bg-purple-500 text-white py-3 px-4 rounded-lg hover:bg-purple-600 transition flex items-center justify-center gap-2 font-medium">
                      <BarChart3 size={20} /> Export Report
                    </button>
                    <button onClick={() => setActiveMenu("Departments")}
                      className="w-full bg-orange-500 text-white py-3 px-4 rounded-lg hover:bg-orange-600 transition flex items-center justify-center gap-2 font-medium">
                      <Building2 size={20} /> Manage Departments
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                {/* Distribution */}
                <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                  <h3 className="text-xl font-bold mb-6 flex items-center text-gray-800">
                    <div className="bg-purple-100 p-2 rounded-lg mr-3"><Building2 className="text-purple-600" size={24} /></div>
                    Employee Distribution
                  </h3>
                  <div className="space-y-4">
                    {[
                      { name: "Engineering", count: 45, pct: "75%", from: "from-blue-500", to: "to-cyan-500", color: "text-blue-600" },
                      { name: "Sales & Marketing", count: 32, pct: "53%", from: "from-green-500", to: "to-emerald-500", color: "text-green-600" },
                      { name: "Human Resources", count: 12, pct: "20%", from: "from-purple-500", to: "to-pink-500", color: "text-purple-600" },
                      { name: "Finance", count: 18, pct: "30%", from: "from-orange-500", to: "to-yellow-500", color: "text-orange-600" },
                      { name: "Operations", count: 23, pct: "38%", from: "from-red-500", to: "to-pink-500", color: "text-red-600" },
                    ].map(d => (
                      <div key={d.name}>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm font-medium">{d.name}</span>
                          <span className={`text-sm font-bold ${d.color}`}>{d.count} employees</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div className={`bg-gradient-to-r ${d.from} ${d.to} h-3 rounded-full`} style={{ width: d.pct }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Top Performers */}
                <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                  <h3 className="text-xl font-bold mb-6 flex items-center text-gray-800">
                    <div className="bg-yellow-100 p-2 rounded-lg mr-3"><Award className="text-yellow-600" size={24} /></div>
                    Top Performers This Month
                  </h3>
                  <div className="space-y-3">
                    {[
                      { medal: "🥇", initials: "AK", name: "Alice Kim", dept: "Engineering", pct: "98%", bg: "bg-blue-500", wrap: "from-yellow-50 to-orange-50" },
                      { medal: "🥈", initials: "MB", name: "Michael Brown", dept: "Sales", pct: "95%", bg: "bg-purple-500", wrap: "bg-gray-50" },
                      { medal: "🥉", initials: "EW", name: "Emma Wilson", dept: "Finance", pct: "93%", bg: "bg-green-500", wrap: "bg-gray-50" },
                    ].map(p => (
                      <div key={p.name} className={`flex items-center gap-3 p-3 bg-gradient-to-r ${p.wrap} rounded-lg`}>
                        <div className="text-2xl">{p.medal}</div>
                        <div className={`h-10 w-10 ${p.bg} rounded-full flex items-center justify-center font-bold text-white flex-shrink-0`}>{p.initials}</div>
                        <div className="flex-1">
                          <p className="font-semibold">{p.name}</p>
                          <p className="text-sm text-gray-500">{p.dept} • {p.pct} Performance</p>
                        </div>
                        <TrendingUp className="text-green-500" size={20} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── EMPLOYEES ── */}
          {activeMenu === "Employees" && (
            <EmployeeTable toast={toast} onAddClick={() => setShowAddEmployee(true)} refreshKey={empRefresh} />
          )}

          {activeMenu === "Departments" && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">Department Management</h3>
              <p className="text-gray-500">Department management interface will be implemented here.</p>
            </div>
          )}
          {activeMenu === "Attendance" && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">Attendance Monitoring</h3>
              <p className="text-gray-500">Attendance tracking interface will be implemented here.</p>
            </div>
          )}
          {activeMenu === "Leave Management" && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">Leave Management</h3>
              <p className="text-gray-500">Leave approval interface will be implemented here.</p>
            </div>
          )}
          {activeMenu === "Payroll" && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">Payroll Management</h3>
              <p className="text-gray-500">Payroll processing interface will be implemented here.</p>
            </div>
          )}
          {activeMenu === "Reports" && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold mb-4">Reports & Analytics</h3>
              <p className="text-gray-500">Reporting interface will be implemented here.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default HRDashboard;