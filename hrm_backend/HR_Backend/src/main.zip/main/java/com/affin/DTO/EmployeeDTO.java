package com.affin.hrm.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {
    private Long id;

    @NotBlank(message = "Employee ID is required")
    private String employeeId;

    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    private String password; // Only used for creation — never returned in responses
    private String nic;
    private LocalDate dob;
    private String address;
    private String phone;
    private String gender;      // "MALE" | "FEMALE" | "OTHER"
    private Long companyId;
    private String companyName;
    private Long departmentId;
    private String departmentName;
    private String role;        // "ADMIN" | "HR_MANAGER" | "EMPLOYEE"
    private String designation;
    private LocalDate joiningDate;
    private LocalDate terminationDate;
    private String status;      // "ACTIVE" | "INACTIVE" | "TERMINATED"
}
